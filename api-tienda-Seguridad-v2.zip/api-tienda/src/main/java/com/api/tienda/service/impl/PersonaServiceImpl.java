package com.api.tienda.service.impl;

import com.api.tienda.constantes.FacturaConstantes;
import com.api.tienda.entity.Persona;
import com.api.tienda.repository.crud.UsuarioCrudRepository;
import com.api.tienda.security.CustomerDetailsService;
import com.api.tienda.security.jwt.JwtUtil;
import com.api.tienda.service.PersonaService;
import com.api.tienda.util.FacturaUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;

import java.util.Map;
import java.util.Objects;

@Slf4j
@Service
public class PersonaServiceImpl implements PersonaService {

    @Autowired
    private UsuarioCrudRepository usuarioCrudRepository;

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private CustomerDetailsService customerDetailsService;


    @Autowired
    private JwtUtil jwtUtil;

    @Override
    public ResponseEntity<String> signUp(Map<String, String> requestMap) {
        log.info("Registro interno de usuario {}",requestMap);
        try{
            if ((validateSignUpMap(requestMap))){
                Persona user =  usuarioCrudRepository.findByEmail(requestMap.get("correo"));
                if (Objects.isNull(user)){
                    usuarioCrudRepository.save(getPersonaFromMap(requestMap));
                    return FacturaUtils.getResponseEntity("Usuario Registrado con Exito ", HttpStatus.CREATED);
                }else{
                    return FacturaUtils.getResponseEntity("El usuario con ese email ya existe", HttpStatus.BAD_REQUEST);
                }
            }else{
                return FacturaUtils.getResponseEntity(FacturaConstantes.INVALID_DATA, HttpStatus.BAD_REQUEST);
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        return FacturaUtils.getResponseEntity(FacturaConstantes.INVALID_DATA,HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @Override
    public ResponseEntity<String> login(Map<String, String> requestMap) {
        log.info("Dentro de login");
        try {
            Authentication authentication = authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(requestMap.get("email"),requestMap.get("password"))
            );

            if(authentication.isAuthenticated()){
                if(customerDetailsService.getUserDetail().getStatus().equalsIgnoreCase("true")){
                    return new ResponseEntity<String>(
                            "{\"token\":\"" +
                                    jwtUtil.generarToken(customerDetailsService.getUserDetail().getCorreo(),
                                    customerDetailsService.getUserDetail().getRole()) + "\"}",
                            HttpStatus.OK);
                }else {
                    return new ResponseEntity<String>("{\"mensaje\":\""+"Espere la aprobacion del adminisitrador "+"\"}",HttpStatus.BAD_REQUEST);
                }
            }
        }catch (Exception e){
            log.error("{}", e);
        }
        return new ResponseEntity<String>("{\"mensaje\":\""+"Credenciales Incorrectas"+"\"}",HttpStatus.BAD_REQUEST);
    }


    private boolean validateSignUpMap(Map<String, String> requestMap){
        if(requestMap.containsKey("Nombre") && requestMap.containsKey("Apellido") && requestMap.containsKey("correo") && requestMap.containsKey("password")){
            return true;
        }
        return false;
    }

    private Persona getPersonaFromMap(Map<String, String> requestMap){
        Persona user = new Persona();
        user.setNombre(requestMap.get("Nombre"));
        user.setApellido(requestMap.get("Apellido"));
        user.setCorreo(requestMap.get("correo"));
        user.setContrasena(requestMap.get("password"));
        user.setStatus("false");
        user.setRole("user");
        return user;
    }
}
