package com.api.tienda.repository.crud;


import com.api.tienda.entity.Persona;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;


@Repository
public interface UsuarioCrudRepository extends JpaRepository<Persona, Integer> {

    Persona findByEmail(@Param(("correo")) String correo);
}
