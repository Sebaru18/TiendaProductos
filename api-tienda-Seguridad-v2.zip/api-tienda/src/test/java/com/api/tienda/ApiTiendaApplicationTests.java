package com.api.tienda;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiTiendaApplicationTests {

	@Test
	void contextLoads() {
	}

}
