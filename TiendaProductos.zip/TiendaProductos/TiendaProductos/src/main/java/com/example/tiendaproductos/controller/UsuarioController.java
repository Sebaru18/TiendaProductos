package com.example.tiendaproductos.controller;

import com.example.tiendaproductos.entity.Usuario;
import com.example.tiendaproductos.service.UsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/user")
public class UsuarioController {


    @Autowired
    private UsuarioService usuarioService;

    @PostMapping("/save")
    public Usuario save(@RequestBody Usuario u){return usuarioService.save(u);
    }


}
