package com.example.tiendaproductos.entity;

import lombok.Data;
import org.springframework.security.core.userdetails.UserDetails;

@Data
public class Usuario extends Persona implements UserDetails {

    private Float saldo;


    public Usuario(Integer ID, String nombre, String apellido, String correo, Float saldo) {
        super(ID, nombre, apellido, correo);
        this.saldo = (float) 0;
    }



}
