package com.example.tiendaproductos.entity;

public enum Rol {

    EMPLEADO,
    USUARIO
}
