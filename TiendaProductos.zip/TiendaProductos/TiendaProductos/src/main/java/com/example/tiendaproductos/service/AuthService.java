package com.example.tiendaproductos.service;

import com.example.tiendaproductos.controller.AuthenticationRequest;
import com.example.tiendaproductos.controller.AuthenticationResponse;
import com.example.tiendaproductos.controller.RegisterRequest;
import com.example.tiendaproductos.repository.EmpleadoRepository;
import com.example.tiendaproductos.repository.UsuarioRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.userdetails.User;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class AuthService {

    private final UsuarioRepository usuarioRepository;

    private final EmpleadoRepository empleadoRepository;


    public AuthenticationResponse registerUser(RegisterRequest request) {
        var user = User.builder()
                .username(request.getCorreo())
                .password()
                .build();
        return null;
    }

    public AuthenticationResponse authenticateUser(AuthenticationRequest request) {
    }

    public AuthenticationResponse registerEmp(RegisterRequest request) {
    }

    public AuthenticationResponse authenticateEmp(AuthenticationRequest request) {
    }



}
