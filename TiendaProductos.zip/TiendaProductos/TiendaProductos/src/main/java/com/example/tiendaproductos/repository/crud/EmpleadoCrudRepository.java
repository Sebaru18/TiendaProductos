package com.example.tiendaproductos.repository.crud;

import com.example.tiendaproductos.entity.Empleado;
import org.springframework.data.repository.CrudRepository;

import java.util.Optional;

public interface EmpleadoCrudRepository extends CrudRepository<Empleado,Integer> {
    Optional<Empleado> findByCorreo (String correo);
}
