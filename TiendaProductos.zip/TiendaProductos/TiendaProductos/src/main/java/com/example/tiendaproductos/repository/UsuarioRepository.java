package com.example.tiendaproductos.repository;


import com.example.tiendaproductos.entity.Usuario;
import com.example.tiendaproductos.repository.crud.UsuarioCrudRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public class UsuarioRepository {

    @Autowired
    private UsuarioCrudRepository usuarioCrudRepository;

    public Usuario save(Usuario u) {return  usuarioCrudRepository.save(u);}

    public Optional<Usuario> findByCorreo(String correo) {
        return usuarioCrudRepository.findByCorreo(correo);
    }

}
