package com.example.tiendaproductos.repository;

import com.example.tiendaproductos.entity.Empleado;
import com.example.tiendaproductos.entity.Product;
import com.example.tiendaproductos.repository.crud.EmpleadoCrudRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public class EmpleadoRepository {

    @Autowired
    private EmpleadoCrudRepository empleadoCrudRepository;

    public Empleado save(Empleado e){return empleadoCrudRepository.save(e);}

    public Optional<Empleado> findByCorreo(String correo ){
        try{ System.out.println(empleadoCrudRepository.findByCorreo(correo));}
        catch(Exception e){return null;}
        return empleadoCrudRepository.findByCorreo(correo);
    }

}
