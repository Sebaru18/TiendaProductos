package com.example.tiendaproductos.service;

import com.example.tiendaproductos.entity.Empleado;
import com.example.tiendaproductos.repository.EmpleadoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class EmpleadoService {

    @Autowired
    private EmpleadoRepository empleadoRepository;

    public Empleado save(Empleado e) {return empleadoRepository.save(e);}

    public Optional<Empleado> findByCorreo(String correo) {return empleadoRepository.findByCorreo(correo);}


}
