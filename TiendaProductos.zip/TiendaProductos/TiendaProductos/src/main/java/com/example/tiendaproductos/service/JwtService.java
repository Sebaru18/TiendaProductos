package com.example.tiendaproductos.service;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import java.security.Key;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;

@Service
public class JwtService {

    private static final String SECRET_KEY = "1589AC3537AF3527DF2E6C9912F27"; //Clave secreta

    public String extractUsername(String token) {
        return extractClaim(token, Claims::getSubject);
    }

    //Metodo para extraer todas las claims contenidas en un JWT
    public Claims extractClaims(String token){
        return Jwts
                .parserBuilder()
                .setSigningKey(getSigningKey())//Algoritmo de encriptacion
                .build()
                .parseClaimsJws(token)
                .getBody();
    }

    //Conversor a base 64 y luego a SHA
    private Key getSigningKey() {
        //A base 64
        byte[] keyBytes = Decoders.BASE64.decode(SECRET_KEY);
        //a SHA
        return Keys.hmacShaKeyFor(keyBytes);
    }

    //Metodo para extraer una Claim especifica de un JWT
    public <T> T extractClaim(String token, Function<Claims, T> claimsResolver){
        final Claims claims = extractClaims(token);
        return claimsResolver.apply(claims);
    }



    //Generador de tokens usando unicamente detalles del usuario
    public String generateToken(UserDetails userDetails){
        return generateToken( new HashMap<>(), userDetails);
    }


    //Generador de Tokens para usuarios usando los detalles del usuario y el objeto usuario
    public String generateToken(
            Map<String, Object> extraClaims,
            UserDetails userDetails
            ){
        return Jwts
                .builder()
                .setClaims(extraClaims)
                .setSubject(userDetails.getUsername()) //Usando el email
                .setIssuedAt(new Date( System.currentTimeMillis())) //Revisar la fecha de expedicion
                .setExpiration(new Date( System.currentTimeMillis()+1000 * 60 * 24)) //Asignar la nueva fecha de expiracion
                .signWith(getSigningKey(), SignatureAlgorithm.HS256) //Entregar la clave privada y mezclarla con el HS256
                .compact();//Unir toodo en un solo string
    }

    //Validador de tokens
    public Boolean tokenValid(String token, UserDetails userDetails){
        final String userName = extractUsername(token);
        //Verificar que el nombre de usuario corresponda con lo enviado y que no haya expirado
        return (userName.equals(userDetails.getUsername())) && !isTokenExpired(token);
    }

    //Comprobar si el token ha expirado
    public Boolean isTokenExpired(String token){
        return extractExpiration(token).before(new Date());
    }

    //Extraer la fecha de expiracion del token
    public Date extractExpiration(String token){
        return extractClaim(token, Claims::getExpiration);
    }

}
