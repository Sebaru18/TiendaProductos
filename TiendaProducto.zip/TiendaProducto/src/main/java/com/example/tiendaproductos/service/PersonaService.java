package com.example.tiendaproductos.service;

import org.springframework.http.ResponseEntity;

import java.util.Map;

public interface PersonaService {

    ResponseEntity<String> signUp(Map<String,String> requestMap);

    ResponseEntity<String> login(Map<String,String> requestMap);
}
