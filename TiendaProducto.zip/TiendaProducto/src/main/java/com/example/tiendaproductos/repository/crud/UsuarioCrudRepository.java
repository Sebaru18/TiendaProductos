package com.example.tiendaproductos.repository.crud;


import com.example.tiendaproductos.entity.Persona;
import org.springframework.boot.autoconfigure.security.SecurityProperties;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;


@Repository
public interface UsuarioCrudRepository extends JpaRepository<Persona, Integer> {

    Persona findByEmail(@Param(("correo")) String correo);
}
